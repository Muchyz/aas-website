import { ChevronRight } from "lucide-react";

export default function Blog() {
  const posts = [
    ["Signs your control panel needs attention before it fails", "Maintenance"],
    ["What a PLC retrofit actually involves", "Automation"],
    ["Getting maintenance contracts right for multi-shift plants", "Case study"],
  ];
  return (
    <section className="container-page section-pad-sm max-w-3xl">
      <p className="eyebrow mb-3">Insights</p>
      <h1 className="text-3xl font-bold text-navy mb-10">From the field</h1>
      <div className="space-y-4">
        {posts.map(([t, tag], i) => (
          <div key={i} className="card-surface overflow-hidden flex items-center gap-4 cursor-pointer group">
            <img
              src={`https://picsum.photos/seed/blog${i}/200/150`}
              alt=""
              className="w-28 h-24 object-cover shrink-0"
            />
            <div className="flex-1 flex items-center justify-between gap-4 py-4 pr-5">
              <div>
                <span className="text-brand text-xs font-medium">{tag}</span>
                <h4 className="font-bold text-navy mt-1 group-hover:text-brand transition-colors">{t}</h4>
              </div>
              <ChevronRight className="text-gray-400 group-hover:text-brand transition-colors shrink-0" size={18} />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
