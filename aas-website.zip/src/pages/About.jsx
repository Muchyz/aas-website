import SectionHeading from "../components/ui/SectionHeading";

const values = [
  ["Our mission", "Deliver automation and electrical systems that run reliably, safely, and without surprises."],
  ["Our approach", "Assess properly, wire cleanly, document everything, and stay reachable after handover."],
  ["Our standard", "Every panel and every line of PLC logic is built the way we'd want it built for our own plant."],
];

const milestones = [
  ["Founded", "AAS opens, taking on panel building and residential-to-light-industrial wiring."],
  ["First major contract", "Automation retrofit for a mid-size manufacturing client."],
  ["Team expansion", "Brought on dedicated PLC programming and maintenance staff."],
  ["Today", "Full-service automation, panel building, and system integration across multiple sectors."],
];

export default function About() {
  return (
    <>
      <section className="section-pad bg-white">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <p className="text-brand font-semibold text-sm uppercase tracking-wide mb-3">About Us</p>
          <h1 className="text-3xl md:text-4xl font-bold text-navy">
            Started in a workshop, grown on referrals.
          </h1>
          <p className="text-gray-600 mt-5 max-w-xl mx-auto">
            AAS was built on a simple idea: do the electrical and automation work properly the first
            time, so the client never has to think about it again.
          </p>
        </div>
        <div className="max-w-5xl mx-auto px-6 mt-10 rounded-xl overflow-hidden shadow-soft-lg">
          <img
            src="https://picsum.photos/seed/aas-team/1200/500"
            alt="AAS technicians at work"
            className="w-full h-64 object-cover"
          />
        </div>
      </section>

      <section className="section-pad bg-offwhite">
        <SectionHeading eyebrow="What Drives Us" title="Mission, approach, standard" />
        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto px-6">
          {values.map(([t, d]) => (
            <div key={t} className="bg-white rounded-xl border border-gray-100 shadow-soft p-6">
              <h4 className="font-bold text-navy">{t}</h4>
              <p className="text-gray-600 text-sm mt-2">{d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section-pad bg-white">
        <SectionHeading eyebrow="Our Story" title="Milestones" />
        <div className="max-w-2xl mx-auto px-6 space-y-6 border-l-2 border-brand/30">
          {milestones.map(([t, d]) => (
            <div key={t} className="relative pl-6">
              <span className="absolute -left-[9px] top-1.5 w-3 h-3 rounded-full bg-brand" />
              <div className="text-navy font-semibold">{t}</div>
              <div className="text-gray-600 text-sm mt-1">{d}</div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
