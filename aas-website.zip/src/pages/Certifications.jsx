import { Shield } from "lucide-react";

export default function Certifications() {
  const items = [
    ["Electrical safety compliance", "Work carried out to recognised national electrical safety standards."],
    ["Vendor-trained technicians", "Staff trained on the PLC and control brands we install and service."],
    ["Insured & licensed", "Fully licensed to operate as an electrical and automation contractor."],
  ];
  return (
    <section className="container-page section-pad-sm">
      <p className="eyebrow mb-3">Trust &amp; compliance</p>
      <h1 className="text-3xl font-bold text-navy mb-4">Certifications</h1>
      <div className="rounded-2xl overflow-hidden shadow-soft mb-12">
        <img src="https://picsum.photos/seed/aas-cert/1200/400" alt="Panel inspection" className="w-full h-56 object-cover" />
      </div>
      <div className="grid md:grid-cols-3 gap-6">
        {items.map(([t, d], i) => (
          <div key={i} className="card-surface p-6">
            <Shield className="text-brand mb-3" size={22} />
            <h4 className="font-bold text-navy">{t}</h4>
            <p className="text-gray-600 text-sm mt-2">{d}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
