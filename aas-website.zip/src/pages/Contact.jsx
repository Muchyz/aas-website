import { Phone, Mail, MapPin } from "lucide-react";
import { CONTACT_PHONE, CONTACT_EMAIL } from "../data";
import WhatsAppButton from "../components/WhatsAppButton";
import SectionHeading from "../components/ui/SectionHeading";

export default function Contact() {
  return (
    <section className="section-pad max-w-4xl mx-auto">
      <SectionHeading eyebrow="Get In Touch" title="Let's talk about your system" />
      <div className="grid md:grid-cols-2 gap-8 px-6">
        <div className="bg-white border border-gray-100 rounded-xl shadow-soft p-6 space-y-5">
          <div className="flex items-center gap-3 text-navy"><Phone className="text-brand" size={18} /> {CONTACT_PHONE}</div>
          <div className="flex items-center gap-3 text-navy"><Mail className="text-brand" size={18} /> {CONTACT_EMAIL}</div>
          <div className="flex items-center gap-3 text-navy"><MapPin className="text-brand" size={18} /> Serving clients across Kenya</div>
          <div className="pt-2"><WhatsAppButton full /></div>
        </div>
        <div className="bg-white border border-gray-100 rounded-xl shadow-soft p-6 space-y-4">
          <input placeholder="Your name" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-navy placeholder:text-gray-400 focus:outline-none focus:border-brand" />
          <input placeholder="Phone or email" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-navy placeholder:text-gray-400 focus:outline-none focus:border-brand" />
          <textarea placeholder="What do you need help with?" rows={4} className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-navy placeholder:text-gray-400 focus:outline-none focus:border-brand" />
          <button className="btn-primary w-full justify-center">Send message</button>
        </div>
      </div>
    </section>
  );
}
