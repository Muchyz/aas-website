import { Link } from "react-router-dom";
import { Zap, Gauge, Package, Cpu, ChevronRight, ArrowUpRight, Quote } from "lucide-react";
import { SERVICES, VALUES, PROCESS } from "../data";
import WhatsAppButton from "../components/WhatsAppButton";

const ICONS = { Zap, Gauge, Package, Cpu };

export default function Home() {
  return (
    <>
      <section className="container-page section-pad grid md:grid-cols-2 gap-12 items-center">
        <div>
          <span className="badge-pill mb-5">
            <Zap size={14} /> Advanced Automation Systems
          </span>
          <h1 className="text-4xl md:text-5xl font-bold text-navy leading-[1.1]">
            Creative engineering solutions, built to run without you standing over them.
          </h1>
          <p className="mt-6 max-w-md text-gray-600 text-lg">
            Electrical installations, instrumentation, product supply and full control &amp; automation
            for factories and plants across Kenya.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <WhatsAppButton />
            <Link to="/projects" className="btn-outline">
              View our work <ArrowUpRight size={16} />
            </Link>
          </div>
        </div>
        <div className="rounded-2xl overflow-hidden shadow-soft-lg">
          <img src="https://picsum.photos/seed/aas-panel/800/600" alt="Industrial control panel" className="w-full h-80 object-cover" />
        </div>
      </section>

      <section className="container-page section-pad-sm">
        <p className="eyebrow mb-3">What we do</p>
        <h2 className="text-2xl md:text-3xl font-bold text-navy mb-10">Our solutions</h2>
        <div className="grid sm:grid-cols-2 gap-6">
          {SERVICES.map((s) => {
            const Icon = ICONS[s.icon];
            return (
              <Link key={s.slug} to={`/services/${s.slug}`} className="card-surface overflow-hidden group">
                <img
                  src={`https://picsum.photos/seed/${s.slug}/500/280`}
                  alt={s.title}
                  className="w-full h-36 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="p-7">
                  <div className="w-12 h-12 rounded-xl bg-brand/10 flex items-center justify-center mb-4">
                    <Icon className="text-brand" size={22} />
                  </div>
                  <h3 className="text-xl font-bold text-navy">{s.title}</h3>
                  <p className="text-gray-600 text-sm mt-2">{s.blurb}</p>
                  <span className="inline-flex items-center gap-1 text-brand text-sm font-medium mt-4">
                    See what's included <ChevronRight size={14} />
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      <section className="container-page section-pad-sm">
        <p className="eyebrow mb-3">How we work</p>
        <h2 className="text-2xl md:text-3xl font-bold text-navy mb-10">From first call to running system</h2>
        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
          {PROCESS.map((step, i) => (
            <div key={step.t} className="card-surface p-6">
              <div className="text-3xl font-bold text-brand/30 mb-3">0{i + 1}</div>
              <h4 className="font-bold text-navy">{step.t}</h4>
              <p className="text-gray-600 text-sm mt-2">{step.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-offwhite">
        <div className="container-page section-pad-sm">
          <p className="eyebrow mb-3">Why clients stay</p>
          <div className="grid md:grid-cols-3 gap-6 mt-8">
            {VALUES.map((v) => (
              <div key={v.t} className="card-surface p-6">
                <h4 className="text-lg font-bold text-navy">{v.t}</h4>
                <p className="text-gray-600 text-sm mt-2">{v.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="container-page section-pad-sm">
        <div className="card-surface p-8 md:p-10 flex flex-col md:flex-row gap-8 items-center">
          <img
            src="https://picsum.photos/seed/aas-testimonial/300/300"
            alt="Client"
            className="w-20 h-20 rounded-full object-cover shrink-0"
          />
          <div>
            <Quote className="text-brand/40 mb-3" size={26} />
            <p className="text-lg text-navy leading-snug max-w-2xl">
              "They rewired our fill line over a weekend so we didn't lose a single production day."
            </p>
            <p className="text-gray-500 text-sm mt-3">Operations Manager, beverage manufacturer</p>
          </div>
        </div>
      </section>

      <section className="container-page section-pad-sm">
        <div className="rounded-2xl bg-brand p-8 md:p-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-soft-lg">
          <div>
            <h3 className="text-2xl font-bold text-white">Have a system that needs attention?</h3>
            <p className="text-white/80 mt-2">Tell us what's happening and we'll get back to you the same day.</p>
          </div>
          <WhatsAppButton />
        </div>
      </section>
    </>
  );
}
