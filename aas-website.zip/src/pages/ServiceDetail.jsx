import { useParams, Link, Navigate } from "react-router-dom";
import { CheckCircle2 } from "lucide-react";
import { SERVICES } from "../data";
import WhatsAppButton from "../components/WhatsAppButton";

export default function ServiceDetail() {
  const { slug } = useParams();
  const service = SERVICES.find((s) => s.slug === slug);
  if (!service) return <Navigate to="/services" replace />;

  return (
    <section className="section-pad max-w-4xl mx-auto">
      <Link to="/services" className="text-brand font-semibold text-sm mb-6 inline-block">&larr; All services</Link>
      <div className="rounded-xl overflow-hidden shadow-soft-lg mb-8">
        <img src={service.image} alt={service.title} className="w-full h-56 object-cover" />
      </div>
      <h1 className="text-3xl font-bold text-navy">{service.title}</h1>
      <p className="text-gray-600 mt-4 max-w-xl">{service.blurb}</p>
      <h3 className="text-navy font-bold mt-10 mb-4">What's included</h3>
      <div className="grid sm:grid-cols-2 gap-3">
        {service.items.map((item) => (
          <div key={item} className="flex items-start gap-3 bg-white border border-gray-100 rounded-xl p-4 shadow-soft">
            <CheckCircle2 className="text-brand shrink-0 mt-0.5" size={18} />
            <span className="text-navy text-sm">{item}</span>
          </div>
        ))}
      </div>
      <div className="mt-10"><WhatsAppButton /></div>
    </section>
  );
}
