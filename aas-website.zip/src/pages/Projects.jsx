export default function Projects() {
  const items = [
    ["Bottling line retrofit", "PLC upgrade for a beverage plant's fill line, cut downtime significantly."],
    ["Warehouse panel rebuild", "Full distribution panel replacement for a logistics facility."],
    ["Cold-store automation", "Temperature control integration for a cold-chain storage facility."],
    ["Bakery line controls", "Control system integration for a mid-size bakery's production line."],
    ["Water treatment panel", "Panel build and wiring for a small water treatment installation."],
    ["Textile plant maintenance", "Ongoing scheduled maintenance contract for a textile manufacturer."],
    ["Genset changeover install", "Automatic mains-genset changeover panel for a manufacturing site with frequent outages."],
    ["SCADA dashboard rollout", "Remote monitoring dashboard for a multi-line production facility."],
    ["Motor control center build", "Custom MCC panel with DOL and VFD starters for a processing plant expansion."],
  ];
  return (
    <section className="container-page section-pad-sm">
      <p className="eyebrow mb-3">Our work</p>
      <h1 className="text-3xl font-bold text-navy mb-4">Recent projects</h1>
      <p className="text-gray-600 max-w-xl mb-12">
        A sample of the panel builds, retrofits, and maintenance contracts we've delivered across Kenya.
      </p>
      <div className="grid md:grid-cols-3 gap-6">
        {items.map(([t, d], i) => (
          <div key={i} className="card-surface overflow-hidden">
            <img src={`https://picsum.photos/seed/project${i}/500/350`} alt={t} className="h-40 w-full object-cover" />
            <div className="p-6">
              <h4 className="font-bold text-navy">{t}</h4>
              <p className="text-gray-600 text-sm mt-2 leading-relaxed">{d}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
