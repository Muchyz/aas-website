export default function Testimonials() {
  const quotes = [
    ["They rewired our fill line over a weekend so we didn't lose a single production day.", "Operations Manager, beverage manufacturer"],
    ["Clean panel work, clearly labeled, no shortcuts. Exactly what we needed.", "Facilities Lead, logistics company"],
    ["Fast to respond when our line went down at 6am. Fixed within hours.", "Plant Supervisor, textile manufacturer"],
    ["Our SCADA retrofit came in on budget and the documentation was better than what the original installer left us.", "Maintenance Manager, bottling plant"],
    ["They found a wiring fault two other contractors had missed. Straightforward, no drama.", "Site Engineer, cold storage facility"],
    ["Reliable for scheduled maintenance — they show up when they say they will.", "Operations Director, bakery group"],
  ];
  return (
    <section className="container-page section-pad-sm max-w-4xl">
      <p className="eyebrow mb-3">Client feedback</p>
      <h1 className="text-3xl font-bold text-navy mb-12">What clients say</h1>
      <div className="grid md:grid-cols-2 gap-6">
        {quotes.map(([q, a], i) => (
          <div key={i} className="card-surface p-6 border-l-4 border-l-brand flex gap-4">
            <img
              src={`https://picsum.photos/seed/client${i}/120/120`}
              alt=""
              className="w-12 h-12 rounded-full object-cover shrink-0"
            />
            <div>
              <p className="text-navy leading-snug">"{q}"</p>
              <p className="text-gray-500 text-sm mt-3">{a}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
