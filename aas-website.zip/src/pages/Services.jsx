import { Link } from "react-router-dom";
import { Zap, Gauge, Package, Cpu, ChevronRight } from "lucide-react";
import { SERVICES } from "../data";

const ICONS = { Zap, Gauge, Package, Cpu };

export default function Services() {
  return (
    <section className="container-page section-pad-sm">
      <p className="eyebrow mb-3">Services</p>
      <h1 className="text-3xl font-bold text-navy mb-10">What we can take off your hands</h1>
      <div className="grid md:grid-cols-2 gap-6">
        {SERVICES.map((s) => {
          const Icon = ICONS[s.icon];
          return (
            <Link key={s.slug} to={`/services/${s.slug}`} className="card-surface overflow-hidden group">
              <img
                src={`https://picsum.photos/seed/${s.slug}/600/280`}
                alt={s.title}
                className="w-full h-36 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="p-7">
                <div className="w-12 h-12 rounded-xl bg-brand/10 flex items-center justify-center mb-4">
                  <Icon className="text-brand" size={22} />
                </div>
                <h3 className="text-lg font-bold text-navy">{s.title}</h3>
                <p className="text-gray-600 text-sm mt-2">{s.blurb}</p>
                <span className="inline-flex items-center gap-1 text-brand text-sm font-medium mt-4">
                  View details <ChevronRight size={14} />
                </span>
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
