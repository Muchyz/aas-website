export default function SectionHeading({ eyebrow, title, subtitle, light }) {
  return (
    <div className="text-center max-w-2xl mx-auto mb-12">
      {eyebrow && (
        <p className="text-sm font-semibold uppercase tracking-wide text-brand mb-3">{eyebrow}</p>
      )}
      <h2 className={`text-3xl font-bold ${light ? "text-white" : "text-navy"}`}>{title}</h2>
      {subtitle && (
        <p className={`mt-3 ${light ? "text-gray-300" : "text-gray-600"}`}>{subtitle}</p>
      )}
      <div className="fingerprint-divider mx-auto mt-5" />
    </div>
  );
}
